Task from Elena
